﻿using Microsoft.AspNetCore.Mvc;
using System.Text.Encodings.Web;

namespace KhumaloCraftEmporium.Controllers
{
    public class CraftsWork : Controller
    {

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult MyWork()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }
        public IActionResult ContactUs()
        {
            return View();
        }
    }
}
